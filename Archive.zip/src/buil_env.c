/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   buil_env.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: flime <flime@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/16 13:08:11 by flime             #+#    #+#             */
/*   Updated: 2014/03/16 13:08:13 by flime            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "shell.h"

/*
** csh
*/
void	buil_env(int ac, char **msh_av, char **env, int opt_end)
{
	/*option -i -iiiiiiiiiiii*/
	(void)ac;
	(void)msh_av;
	(void)opt_end;
	ft_puttab(env);
}
